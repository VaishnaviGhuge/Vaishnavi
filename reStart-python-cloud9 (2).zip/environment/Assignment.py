#Q.1 Find largest of three numbers using if
a = int(input('Enter first number  : '))
b = int(input('Enter second number : '))
c = int(input('Enter third number  : '))

largest = 0

if a > b and a > c:
    largest = a
if b > a and b > c:
    largest = b
if c > a and c > b:
    largest = c

print(largest, "is the largest of three numbers.")

# Q.2 Python program to check if the input number is odd or even.
# A number is even if division by 2 gives a remainder of 0.
# If the remainder is 1, it is an odd number.

num = int(input("Enter a number: "))
if (num % 2) == 0:
   print("{0} is Even".format(num))
else:
   print("{0} is Odd".format(num))

# Q.3To Swap the values of two variables using Addition and subtraction operator.  
P = int( input("Please enter value for P: "))
Q = int( input("Please enter value for Q: "))
P = P + Q
Q = P - Q
P = P - Q
print ("The Value of P after swapping: ", P)
print ("The Value of Q after swapping: ", Q)

#Q.4 Number to be checked for prime
n = 5
# Check if the number is greater than 1
if n > 1:
	for i in range(2, int(n/2)+1):
		if (n % i) == 0:
			print(num, "is not a prime number")
		break
	else:
		print(n, "is a prime number")
# If the number is less than 1, its also not a prime number.
else:
	print(n, "is not a prime number")
   
# Q.5 Python program to find factorial of given number.
import math
def fact(n):
     return(math.factorial(n))
num = int(input("Enter the number:"))
f = fact(num)
print("Factorial of", num, "is", f)


#Q.6 Displays individual characters from given string  
string = "characters";
print("Individual characters from given string:");  
#Iterate through the string and display individual character  
for i in range(0, len(string)):  
    print(string[i], end="  ");  
    
# Q.7 Code to iterate over a list
list = [1, 3, 5, 7, 9]
# Using for loop
for i in list:
         print(i)

# Q.8 Multiplication table (from 1 to 10) in Python
num = 12
# To take input from the user
# num = int(input("Display multiplication table of? "))
# Iterate 10 times from i = 1 to 10
for i in range(1, 11):
   print(num, 'x', i, '=', num*i)
   
# Q.9 Python program to print numbers from n to 1 using while loop
number = int(input("Please Enter any Number: "))
i = number
while ( i >= 1):
    print (i, end = '  ')
    i = i - 1
    
#Q.10 Program to display the Fibonacci sequence up to 25 term
# first two terms
n1, n2 = 0, 1
count = 0
# check if the number of terms is valid
nterms = 25
if nterms <= 0:
   print("Please enter a positive integer")
# if there is only one term, return n1
elif nterms == 1:
   print("Fibonacci sequence upto",nterms,":")
   print(n1)
# generate fibonacci sequence
else:
   print("Fibonacci sequence:")
   while count <= nterms:
       print(n1)
       nth = n1 + n2
       # update values
       n1 = n2
       n2 = nth
       count += 1
   
   
   
   
   
   
   
   
   
   