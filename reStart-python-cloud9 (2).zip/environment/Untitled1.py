name = "John"
print("Hello " + name + ".")
age = 40
print(name + " is " + str(age) + " years old.")